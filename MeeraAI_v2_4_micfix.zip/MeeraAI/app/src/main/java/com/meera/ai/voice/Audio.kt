package com.meera.ai.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import com.meera.ai.Meera
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

/** Live microphone capture: 16 kHz mono PCM16, 100 ms chunks. Reports a readable problem if the mic cannot record. */
class AudioCapture(
    private val onProblem: (String) -> Unit = {},
    private val onChunk: (ByteArray) -> Unit
) {
    @Volatile var muted = false
    private var rec: AudioRecord? = null
    private var job: Job? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    @SuppressLint("MissingPermission") // permission is checked by CallController before start()
    fun start(scope: CoroutineScope) {
        if (job != null) return // never run two mic sessions
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        // Try the call-tuned source first, then the plain microphone (some phones refuse VOICE_COMMUNICATION).
        val sources = intArrayOf(MediaRecorder.AudioSource.VOICE_COMMUNICATION, MediaRecorder.AudioSource.MIC)
        var good: AudioRecord? = null
        var why = "unknown"
        for (src in sources) {
            val r = try {
                AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400) * 2)
            } catch (e: Exception) { why = "AudioRecord error: ${e.message}"; continue }
            if (r.state != AudioRecord.STATE_INITIALIZED) { why = "mic could not be opened (source $src)"; r.release(); continue }
            try { r.startRecording() } catch (e: Exception) { why = "startRecording failed: ${e.message}"; r.release(); continue }
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) { why = "mic did not start (source $src)"; r.release(); continue }
            good = r
            break
        }
        val r = good ?: throw IllegalStateException("Microphone could not start: $why. Check Android microphone permission / privacy switch / other app using the mic.")
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.setEnabled(true) }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.setEnabled(true) }
        rec = r
        job = scope.launch(Dispatchers.IO) {
            val buf = ByteArray(3200)
            var silentChunks = 0
            while (isActive) {
                val n = r.read(buf, 0, buf.size)
                if (n < 0) { onProblem("Microphone stopped (read error $n)."); break }
                if (n == 0) { delay(20); continue }
                // all-zero audio for ~4 s = the phone is silencing the mic (privacy switch, permission, another app)
                var peak = 0
                var i = 0
                while (i + 1 < n) {
                    val v = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
                    val a = if (v < 0) -v else v
                    if (a > peak) peak = a
                    i += 2
                }
                if (peak == 0) {
                    silentChunks++
                    if (silentChunks == 40) { onProblem("Microphone gives only silence. Allow Microphone for Meera in Android Settings and turn off the mic privacy switch."); break }
                } else silentChunks = 0
                if (!muted) onChunk(buf.copyOf(n))
            }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        rec?.let {
            try { it.stop() } catch (e: Exception) { }
            it.release()
        }
        rec = null
        try { aec?.release() } catch (e: Exception) { }
        try { ns?.release() } catch (e: Exception) { }
        aec = null; ns = null
    }
}

/** Streaming PCM16 player at 24 kHz (Gemini Live output rate). */
class AudioPlayer {
    private val rate = 24000
    private val track: AudioTrack
    private val queue = Channel<ByteArray>(Channel.UNLIMITED)
    private val framesWritten = AtomicLong(0)
    private var writer: Job? = null
    @Volatile private var epoch = 0

    init {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
    }

    fun start(scope: CoroutineScope) {
        if (writer != null) return
        writer = scope.launch(Dispatchers.IO) {
            for (chunk in queue) {
                val myEpoch = epoch
                var off = 0
                while (off < chunk.size && isActive && myEpoch == epoch) {
                    val n = track.write(chunk, off, minOf(4800, chunk.size - off))
                    if (n <= 0) break
                    Meera.aura.feedPcm(chunk, off, n) // real loudness of what is playing -> Aura border pulse
                    off += n
                    framesWritten.addAndGet((n / 2).toLong())
                }
            }
        }
    }

    fun enqueue(pcm: ByteArray) {
        queue.trySend(pcm)
    }

    /** Barge-in: drop everything queued and stop sound immediately. */
    fun flush() {
        epoch++
        while (queue.tryReceive().isSuccess) { /* drain */ }
        try {
            track.pause(); track.flush(); track.play()
        } catch (e: Exception) { }
        framesWritten.set(0)
    }

    /** Suspends until what was queued has really been played. */
    suspend fun awaitDrained() {
        var guard = 0
        while (guard < 600) { // max 30 s
            val head = try { track.playbackHeadPosition.toLong() } catch (e: Exception) { return }
            if (head >= framesWritten.get() && queue.isEmpty) return
            delay(50); guard++
        }
    }

    fun release() {
        writer?.cancel(); writer = null
        queue.close()
        try { track.pause(); track.flush(); track.release() } catch (e: Exception) { }
    }
}
