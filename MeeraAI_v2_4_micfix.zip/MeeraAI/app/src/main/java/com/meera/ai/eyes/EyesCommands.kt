package com.meera.ai.eyes

enum class EyesCmd { OPEN, CLOSE }

/**
 * Meera Eyes voice/text commands, matched LOCALLY (no Gemini involved).
 * The camera must never open by itself: only a short, explicit sentence from the user counts.
 *
 *   OPEN : "Meera open your eyes", "aankhein kholo", "meera aankhein khol", "camera on"
 *   CLOSE: "close your eyes", "aankhein band karo", "meera aankhein band kar", "camera off"
 *
 * Spelling variants (aankhen / ankhein / आँखें ...) and filler words ("please", "yaar", "na") are accepted.
 * A sentence with a negation ("aankhein mat kholo", "don't open your eyes") is NOT a command.
 */
object EyesCommands {
    private val eyeRegex = Regex("^a{1,2}n?k{1,2}h(e|ei|ai|a)?(i?n|on)?s?$")
    private val eyeWords = setOf("eyes", "eye", "آنکھیں", "آنکھ", "آنکھوں", "انکھیں", "آنکھے")
    private val cameraWords = setOf("camera", "cam", "کیمرہ", "کیمرا")

    // for "... eyes": open / close verbs
    private val openVerbs = setOf("kholo", "khol", "kholna", "kholiye", "kholdo", "kholde", "khole", "open", "on", "کھولو", "کھول", "کھولیں", "کھولیے", "کھولنا")
    private val closeVerbs = setOf("band", "bandh", "bnd", "bandkaro", "bandkar", "close", "off", "shut", "بند")

    // for "camera ...": only on/off words (NOT "kholo": "camera kholo" is the existing phone action that opens the system camera app)
    private val camOn = setOf("on", "chalu", "start", "shuru", "آن", "چالو", "شروع")
    private val camOff = setOf("off", "band", "bandh", "stop", "آف", "بند")

    private val negations = setOf("nahi", "nahin", "mat", "not", "dont", "don", "never", "نہیں", "مت", "نہ")

    private fun tokenize(text: String): List<String> =
        text.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }

    private fun isEye(t: String) = t in eyeWords || eyeRegex.matches(t)

    /** Returns the command if [text] is one, otherwise null. */
    fun match(text: String): EyesCmd? {
        val tokens = tokenize(text)
        if (tokens.isEmpty() || tokens.size > 9) return null
        if (tokens.any { it in negations }) return null
        val hasEye = tokens.any { isEye(it) }
        val hasCam = tokens.any { it in cameraWords }
        val open: Boolean
        val close: Boolean
        when {
            hasEye -> {
                open = tokens.any { it in openVerbs }
                close = tokens.any { it in closeVerbs }
            }
            hasCam -> {
                open = tokens.any { it in camOn }
                close = tokens.any { it in camOff }
            }
            else -> return null
        }
        return when {
            open && !close -> EyesCmd.OPEN
            close && !open -> EyesCmd.CLOSE
            else -> null
        }
    }
}
