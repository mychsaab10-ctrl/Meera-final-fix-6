package com.meera.ai.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.ai.Answer
import com.meera.ai.ai.ChatMsg
import com.meera.ai.automation.LocationFlow
import com.meera.ai.automation.WhereAmI
import com.meera.ai.data.AutoMemory
import com.meera.ai.eyes.EyesCommands
import com.meera.ai.ai.GeminiException
import com.meera.ai.ai.LiveSession
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

enum class CallState { Idle, Connecting, Listening, Thinking, Speaking, Error }
data class Subtitle(val who: String, val text: String)

/**
 * Calling mode. Primary: Gemini Live API (native audio over WebSocket).
 * Fallback: SpeechRecognizer -> Gemini text -> TextToSpeech, loop.
 * All state changes happen on the main thread.
 */
class CallController(private val ctx: Context, private val scope: CoroutineScope) {
    val state = MutableStateFlow(CallState.Idle)
    val status = MutableStateFlow("Not connected")
    val subtitles = MutableStateFlow<List<Subtitle>>(emptyList())
    val muted = MutableStateFlow(false)
    val speaker = MutableStateFlow(true)
    val seconds = MutableStateFlow(0)
    val modeLabel = MutableStateFlow("")
    /** Avatar emotion during the call (words-based guess). */
    val callMood = MutableStateFlow("normal")
    /** True while the PHONE's own voice speaks something private (the "where am I?" answer). The avatar shows the talking clips. */
    val privateSpeech = MutableStateFlow(false)

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile private var active = false
    private var gen = 0
    @Volatile private var live: LiveSession? = null
    @Volatile private var liveReady = false
    private var capture: AudioCapture? = null
    private var player: AudioPlayer? = null
    private var ignoreAudio = false
    private var timerJob: Job? = null
    private var drainJob: Job? = null

    private var stt: Stt? = null
    private var tts: TtsEngine? = null
    private var fbJob: Job? = null
    private val history = mutableListOf<ChatMsg>()
    private var errorStreak = 0

    private var liveWho = ""
    private val liveBuf = StringBuilder()

    // Meera Eyes + Live call
    private var eyesCheckJob: Job? = null
    @Volatile private var videoFirstAt = 0L

    private fun hasMic() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun start() {
        if (active) return // prevents duplicate mic sessions
        if (!hasMic()) { state.value = CallState.Error; status.value = "Microphone permission denied. Allow it and try again."; return }
        val key = Meera.keys.load()
        if (key == null) { state.value = CallState.Error; status.value = "No API key. Add one in Settings."; return }
        active = true
        gen++
        muted.value = false
        subtitles.value = emptyList()
        seconds.value = 0
        history.clear()
        errorStreak = 0
        liveWho = ""
        videoFirstAt = 0L
        callMood.value = "normal"
        state.value = CallState.Connecting
        status.value = "Connecting…"
        startServiceAndTimer()
        if (Meera.settings.useLive) startLive(key) else startFallback("Text-model voice mode")
    }

    // ───────────── private speech (location answer) ─────────────

    /**
     * The "where am I?" answer is spoken by the phone's own TTS. While it speaks, nothing from the microphone may reach Gemini
     * (the speaker could be heard by the mic and transcribed): Live = the microphone is not sent, Fallback = the recognizer is paused.
     */
    fun beginPrivateSpeech() {
        if (!active) return
        privateSpeech.value = true
        capture?.muted = true
        if (modeLabel.value == "Fallback") stt?.cancel()
    }

    fun endPrivateSpeech() {
        if (!privateSpeech.value) return
        privateSpeech.value = false
        capture?.muted = muted.value
        if (active && modeLabel.value == "Fallback" && state.value == CallState.Listening) listen()
    }

    private fun startServiceAndTimer() {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, CallService::class.java))
        } catch (e: Exception) { /* call still works while the app is in the foreground */ }
        timerJob?.cancel()
        timerJob = scope.launch { while (isActive) { delay(1000); seconds.value = seconds.value + 1 } }
    }

    // ───────────── Live API path ─────────────
    private fun startLive(key: String) {
        modeLabel.value = "Live"
        status.value = "Connecting to Gemini Live…"
        applyRoute(true)
        val g = gen
        val pl = AudioPlayer().also { it.start(scope) }
        player = pl
        liveReady = false
        val s = LiveSession(
            key, Meera.settings.liveModel, Persona.system("call", live = true), Meera.settings.voice, Persona.liveTools,
            object : LiveSession.Callbacks {
                override fun onReady() { scope.launch { if (ok(g)) { liveReady = true; state.value = CallState.Listening; status.value = "Connected - speak now"; startCapture() } } }
                override fun onAudio(pcm: ByteArray) {
                    scope.launch {
                        if (!ok(g) || ignoreAudio) return@launch
                        if (state.value != CallState.Speaking) { state.value = CallState.Speaking; status.value = "Meera is speaking" }
                        drainJob?.cancel()
                        player?.enqueue(pcm)
                    }
                }
                override fun onInText(t: String) { scope.launch { if (ok(g)) { frag("You", t); if (state.value == CallState.Listening) status.value = "Hearing you…" } } }
                override fun onOutText(t: String) { scope.launch { if (ok(g)) frag("Meera", t) } }
                override fun onInterrupted() { scope.launch { if (ok(g)) { player?.flush(); ignoreAudio = false; liveWho = ""; state.value = CallState.Listening; status.value = "Listening…" } } }
                override fun onTurnComplete() {
                    scope.launch {
                        if (!ok(g)) return@launch
                        ignoreAudio = false; liveWho = ""
                        drainJob?.cancel()
                        drainJob = scope.launch {
                            player?.awaitDrained()
                            if (ok(g)) { state.value = CallState.Listening; status.value = "Listening…" } // auto-return to listening
                        }
                    }
                }
                override fun onToolCall(id: String, name: String, args: JSONObject) {
                    scope.launch {
                        if (!ok(g)) return@launch
                        state.value = CallState.Thinking; status.value = "Working on it…"
                        // let the spoken "yes" transcription arrive before checking it
                        if (name == "confirm_pending" || name == "open_eyes" || name == "close_eyes") delay(1000)
                        val r = if (name == "look_camera") Meera.eyes.lookTool(args) else Meera.handleCall(name, args)
                        live?.sendToolResponse(id, name, r.forLive())
                    }
                }
                override fun onClosed(reason: String, wasReady: Boolean) {
                    scope.launch {
                        if (!ok(g)) return@launch
                        val videoKilled = wasReady && videoFirstAt != 0L &&
                            SystemClock.elapsedRealtime() - videoFirstAt < 10_000L && !reason.startsWith("network error")
                        cleanup()
                        if (videoKilled) {
                            // The server closed the session right after the first camera frame: this Live model most likely
                            // does not accept video. Switch to "snapshot" mode (one frame per question) for the next call.
                            Meera.settings.liveVideo = "snapshot"
                            Meera.toast("The Live model did not accept camera frames. Snapshot mode is now on - please start the call again.")
                            fail("Live video is not supported ($reason). Snapshot mode is now on - please start the call again.")
                            return@launch
                        }
                        if (!wasReady && Meera.settings.autoFallback) {
                            active = true
                            gen++
                            startServiceAndTimer()
                            startFallback("Live unavailable ($reason). Using fallback voice mode.")
                        } else {
                            fail(if (wasReady) "Connection lost: $reason" else "Could not connect: $reason")
                        }
                    }
                }
            }
        )
        live = s
        s.connect()
    }

    private fun ok(g: Int) = active && g == gen

    private fun startCapture() {
        if (capture != null) return
        try {
            val g = gen
            val c = AudioCapture(onProblem = { msg -> scope.launch { if (ok(g)) fail(msg) } }) { pcm -> live?.sendAudio(pcm) }
            c.muted = muted.value
            c.start(scope)
            capture = c
        } catch (e: Exception) {
            fail(e.message ?: "Microphone error")
        }
    }

    private fun frag(who: String, t: String) {
        if (who != liveWho) {
            if (liveWho == "You") AutoMemory.consider(liveBuf.toString()) // the user's sentence is finished: remember lasting facts
            liveWho = who; liveBuf.clear()
            subtitles.value = (subtitles.value + Subtitle(who, "")).takeLast(40)
        }
        liveBuf.append(t)
        if (who == "You") {
            Meera.lastUserText = liveBuf.toString()
            scheduleEyesCommand()
            scheduleLocationCommand()
        } else callMood.value = Mood.guess(liveBuf.toString())
        val l = subtitles.value.toMutableList()
        if (l.isNotEmpty()) l[l.lastIndex] = Subtitle(who, liveBuf.toString())
        subtitles.value = l
    }

    // ───────────── Meera Eyes in the Live call ─────────────

    /**
     * Local command detection on the user's transcription (never trusts Gemini). We wait 0.8 s of silence in the
     * transcription so that "camera on the table..." is not mistaken for "camera on". If the Live model also calls
     * open_eyes/close_eyes, Meera.handleCall verifies the same words; running the command twice is harmless.
     */
    private fun scheduleEyesCommand() {
        eyesCheckJob?.cancel()
        val said = liveBuf.toString()
        val cmd = EyesCommands.match(said) ?: return
        val g = gen
        eyesCheckJob = scope.launch {
            delay(800)
            if (!ok(g)) return@launch
            if (Meera.lastUserText == said && EyesCommands.match(said) == cmd) Meera.eyes.runCommand(cmd)
        }
    }

    // ───────────── "Where am I?" in the Live call ─────────────

    private var locationCheckJob: Job? = null

    /**
     * Local detection on the user's transcription (never Gemini's words), like the Eyes commands:
     *  - "where am I?" -> the app asks "Can I check your location now? (yes / no)" with the phone's own voice;
     *  - then the user's "yes" / "haan" -> the location is read (screen card + phone voice only); "no" -> nothing happens.
     * Gemini's spoken reaction to those sentences is silenced (best effort), the microphone is paused while the address is spoken,
     * and Gemini is told nothing about the result. The confirm_pending tool cannot confirm this question.
     */
    private fun scheduleLocationCommand() {
        locationCheckJob?.cancel()
        val said = liveBuf.toString()
        val answering = Meera.waitingForLocationAnswer()
        val asking = !answering && WhereAmI.match(said)
        if (!answering && !asking) return
        if (answering && Answer.parse(said) == Answer.UNSURE) return
        val g = gen
        locationCheckJob = scope.launch {
            delay(if (answering) 600 else 800) // wait for the end of the sentence in the transcription
            if (!ok(g) || Meera.lastUserText != said) return@launch
            silenceModel()
            val text = if (answering) Meera.interceptAnswer(said) else Meera.askWhereAmI(said)?.text
            if (text != null) {
                subtitles.value = (subtitles.value + Subtitle("Meera", text)).takeLast(40)
                LocationFlow.sayPrivately(text) // phone voice, microphone paused while it speaks
            }
        }
    }

    /** Hide the Live model's own reaction to a sentence that the app handles locally. */
    private fun silenceModel() {
        player?.flush()
        ignoreAudio = true
        drainJob?.cancel()
    }

    /** True when Eyes frames should be streamed to the Live model (Live connected + setting "stream"). */
    fun canSendVideo(): Boolean =
        active && liveReady && live != null && Meera.settings.liveVideo == "stream"

    /** Called by the camera thread, max ~1 per second. */
    fun sendVideoFrame(jpeg: ByteArray) {
        val s = live ?: return
        if (s.sendVideoFrame(jpeg) && videoFirstAt == 0L) videoFirstAt = SystemClock.elapsedRealtime()
    }

    // ───────────── Fallback path ─────────────
    private fun startFallback(note: String) {
        modeLabel.value = "Fallback"
        status.value = note
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            fail("Speech recognition is not available on this phone (install/enable the Google app).")
            return
        }
        stt = Stt(ctx)
        tts = TtsEngine(ctx)
        scope.launch { delay(600); if (active) listen() }
    }

    private fun listen() {
        if (!active || modeLabel.value != "Fallback") return
        if (privateSpeech.value) { // never listen while the phone speaks the private location answer
            val gp = gen
            scope.launch { delay(500); if (ok(gp)) listen() }
            return
        }
        if (muted.value) {
            state.value = CallState.Listening; status.value = "Muted"
            val g = gen
            scope.launch { delay(700); if (ok(g)) listen() }
            return
        }
        state.value = CallState.Listening
        status.value = "Listening…"
        stt?.start(
            Meera.settings.sttLang,
            onPart = { status.value = "Hearing: $it" },
            onDone = { onUserSaid(it) },
            onErr = { onSttError(it) }
        )
    }

    private fun onSttError(code: Int) {
        if (!active) return
        val g = gen
        when (code) {
            SpeechRecognizer.ERROR_CLIENT -> {}
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> fail("Microphone permission denied.")
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                status.value = "Silence… still listening"
                scope.launch { delay(300); if (ok(g)) listen() }
            }
            else -> {
                errorStreak++
                if (errorStreak > 4) { fail(Stt.errorText(code) + " - too many failures."); return }
                status.value = Stt.errorText(code) + ", retrying…"
                stt?.destroy(); stt = Stt(ctx)
                scope.launch { delay(1500); if (ok(g)) listen() }
            }
        }
    }

    private fun onUserSaid(text: String) {
        if (!active || state.value == CallState.Thinking) return
        errorStreak = 0
        Meera.lastUserText = text
        subtitles.value = (subtitles.value + Subtitle("You", text)).takeLast(40)
        val g = gen
        // answer to a pending question ("save this?" / "send it?")
        Meera.interceptAnswer(text)?.let { ans ->
            subtitles.value = (subtitles.value + Subtitle("Meera", ans)).takeLast(40)
            callMood.value = Mood.guess(ans)
            state.value = CallState.Speaking
            status.value = "Meera is speaking"
            tts?.speak(ans) { scope.launch { if (ok(g)) listen() } } ?: listen()
            return
        }
        // "Where am I?": matched locally, never sent to Gemini. Meera asks "Can I check your location now? (yes / no)".
        Meera.askWhereAmI(text)?.let { out ->
            subtitles.value = (subtitles.value + Subtitle("Meera", out.text)).takeLast(40)
            callMood.value = "normal"
            state.value = CallState.Speaking
            status.value = "Meera is speaking"
            tts?.speak(out.text) { scope.launch { if (ok(g)) listen() } } ?: listen()
            return
        }
        // Meera Eyes command ("aankhein kholo" / "camera off"): matched locally, not sent to Gemini
        EyesCommands.match(text)?.let { cmd ->
            val ans = Meera.eyes.runCommand(cmd)
            subtitles.value = (subtitles.value + Subtitle("Meera", ans)).takeLast(40)
            callMood.value = Mood.guess(ans)
            state.value = CallState.Speaking
            status.value = "Meera is speaking"
            tts?.speak(ans) { scope.launch { if (ok(g)) listen() } } ?: listen()
            return
        }
        AutoMemory.consider(text)
        state.value = CallState.Thinking
        status.value = "Thinking…"
        history.add(ChatMsg("user", text))
        fbJob?.cancel()
        fbJob = scope.launch {
            try {
                val s = Meera.settings
                // Eyes ON: the current camera frame goes along with the question (Q&A about what the camera sees)
                val eyesOn = Meera.eyes.isOpen.value
                val frame = if (eyesOn) Meera.eyes.snapshot() else null
                val shots = if (frame != null) listOf(Meera.eyes.attach(frame)) else emptyList()
                val r = Meera.gemini.generate(
                    s.model, Persona.system("call"), history.takeLast(20), s.temperature.toDouble(),
                    attachments = shots, tools = Persona.tools
                )
                if (!ok(g)) return@launch
                val results = r.calls.map { Meera.handleCall(it.name, it.args) }
                val asks = results.filter { it.ask }.joinToString(" ") { it.text }
                val said = Mood.strip(r.text)
                val reply = listOf(said, asks).filter { it.isNotBlank() }.joinToString(" ")
                    .ifBlank { results.joinToString(". ") { it.text } }
                    .ifBlank { "Hmm, I didn't get that." }
                callMood.value = Mood.guess(reply)
                if (eyesOn) Meera.eyes.noteCallAnswer(text, reply) // also show it on the Eyes card
                history.add(ChatMsg("model", reply))
                subtitles.value = (subtitles.value + Subtitle("Meera", reply)).takeLast(40)
                state.value = CallState.Speaking
                status.value = "Meera is speaking"
                tts?.speak(reply) { scope.launch { if (ok(g)) listen() } } ?: listen()
            } catch (e: GeminiException) {
                if (!ok(g)) return@launch
                errorStreak++
                status.value = e.message ?: "Error"
                if (errorStreak > 3) { fail(e.message ?: "Too many errors"); return@launch }
                delay(1500)
                if (ok(g)) listen()
            }
        }
    }

    // ───────────── controls ─────────────
    fun toggleMute() {
        muted.value = !muted.value
        capture?.muted = muted.value
        if (muted.value && modeLabel.value == "Fallback") stt?.cancel()
    }

    fun toggleSpeaker() {
        speaker.value = !speaker.value
        applyRoute(modeLabel.value == "Live")
    }

    /** Barge-in button: stop Meera talking right now and listen. */
    fun interrupt() {
        if (!active) return
        if (modeLabel.value == "Live") {
            player?.flush(); ignoreAudio = true; drainJob?.cancel()
            state.value = CallState.Listening; status.value = "Listening…"
        } else {
            tts?.stop(); fbJob?.cancel(); listen()
        }
    }

    fun stop() {
        if (!active && state.value == CallState.Idle) return
        active = false
        gen++
        cleanup()
        state.value = CallState.Idle
        status.value = "Call ended"
    }

    private fun fail(msg: String) {
        cleanup()
        active = false
        gen++
        state.value = CallState.Error
        status.value = msg
    }

    private fun cleanup() {
        timerJob?.cancel(); timerJob = null
        drainJob?.cancel(); drainJob = null
        fbJob?.cancel(); fbJob = null
        eyesCheckJob?.cancel(); eyesCheckJob = null
        locationCheckJob?.cancel(); locationCheckJob = null
        privateSpeech.value = false
        capture?.stop(); capture = null
        live?.close(); live = null
        player?.release(); player = null
        stt?.destroy(); stt = null
        tts?.shutdown(); tts = null
        ignoreAudio = false
        liveReady = false
        restoreRoute()
        try { ctx.stopService(Intent(ctx, CallService::class.java)) } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun applyRoute(inCommunication: Boolean) {
        if (inCommunication) audio.mode = AudioManager.MODE_IN_COMMUNICATION
        val on = speaker.value
        if (Build.VERSION.SDK_INT >= 31) {
            if (on) {
                audio.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    ?.let { audio.setCommunicationDevice(it) }
            } else audio.clearCommunicationDevice()
        } else {
            audio.isSpeakerphoneOn = on
        }
    }

    @Suppress("DEPRECATION")
    private fun restoreRoute() {
        try {
            if (Build.VERSION.SDK_INT >= 31) audio.clearCommunicationDevice() else audio.isSpeakerphoneOn = false
            audio.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) { }
    }
}
