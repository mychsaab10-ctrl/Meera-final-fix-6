package com.meera.ai.eyes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * CameraX wrapper: live preview + a light analysis stream. NOTHING is recorded or saved - there is no
 * ImageCapture / VideoCapture use case, no file, no MediaStore. Frames live only in memory.
 */
class EyesCamera(private val ctx: Context, private val eyes: EyesController) {
    private var token = 0
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    private var executor: ExecutorService? = null

    /** Called by the Eyes screen on the main thread. Safe to call again (e.g. front/back switch). */
    fun bind(owner: LifecycleOwner, view: PreviewView, front: Boolean) {
        val my = ++token
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            // the screen may have been closed again before CameraX was ready
            if (my != token || !eyes.isOpen.value) return@addListener
            try {
                val p = future.get()
                provider = p
                val wanted = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val other = if (front) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                if (!p.hasCamera(wanted)) {
                    if (p.hasCamera(other)) {
                        // this phone has no such camera: switch lens (the screen re-binds because lensFront changed)
                        eyes.lensFront.value = !front
                    } else {
                        eyes.onCameraError("No camera was found on this phone.")
                    }
                    return@addListener
                }

                // Preview and analysis share the same 4:3 field of view, so HUD boxes line up with the picture.
                val ratio = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .build()
                val preview = Preview.Builder().setResolutionSelector(ratio).build()
                preview.setSurfaceProvider(view.surfaceProvider)

                val small = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    )
                    .build()
                val an = ImageAnalysis.Builder()
                    .setResolutionSelector(small)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST) // never queue frames
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                val ex = executor ?: Executors.newSingleThreadExecutor().also { executor = it }
                an.setAnalyzer(ex, FrameAnalyzer(eyes)) // analysis runs on this background thread, never on the UI thread
                analysis = an

                p.unbindAll()
                p.bindToLifecycle(owner, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, preview, an)
            } catch (e: Exception) {
                eyes.onCameraError("The camera did not start: ${e.message ?: "unknown error"}")
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    /** Releases the camera. Called when the Eyes screen leaves the composition (close, background, auto-stop). */
    fun unbind() {
        token++ // cancels a bind() that has not finished yet
        try { analysis?.clearAnalyzer() } catch (e: Exception) { }
        analysis = null
        try { provider?.unbindAll() } catch (e: Exception) { }
        executor?.shutdown()
        executor = null
    }
}

/**
 * Converts only the frames that are actually needed (HUD scan due / Live second due / a question waiting)
 * into a 640 px JPEG (quality 70). Every other camera frame is closed immediately - this keeps the phone cool.
 */
class FrameAnalyzer(private val eyes: EyesController) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (!eyes.wantsFrame(now)) return
            val src = image.toBitmap()
            val rot = image.imageInfo.rotationDegrees
            val longest = max(src.width, src.height)
            val scale = if (longest > MAX_SIDE) MAX_SIDE.toFloat() / longest else 1f
            val out: Bitmap = if (rot == 0 && scale == 1f) {
                src
            } else {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                if (scale != 1f) m.postScale(scale, scale)
                Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            }
            val w = out.width
            val h = out.height
            val bos = ByteArrayOutputStream(48 * 1024)
            out.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, bos)
            if (out !== src) out.recycle()
            src.recycle() // free the bitmaps right away (4 GB phones)
            eyes.onFrame(bos.toByteArray(), w, h, now)
        } catch (t: Throwable) {
            // skip this frame; the next one will try again
        } finally {
            image.close()
        }
    }

    companion object {
        const val MAX_SIDE = 640
        const val JPEG_QUALITY = 70
    }
}
