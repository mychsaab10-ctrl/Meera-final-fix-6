package com.meera.ai.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.meera.ai.Meera
import com.meera.ai.ai.Answer
import com.meera.ai.ai.ChatMsg
import com.meera.ai.automation.WhereAmI
import com.meera.ai.ai.GeminiException
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import com.meera.ai.data.AutoMemory
import com.meera.ai.eyes.EyesCommands
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * role: "user" | "model" | "system" (system = tool results / notices)
 * [local] = a message of the local "where am I?" flow: shown on screen only, never sent to Gemini and never saved to the chat file.
 */
class UiMsg(val role: String, val text: String, val local: Boolean = false)

class ChatSession(val kind: String) {
    val messages = mutableStateListOf<UiMsg>()
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var searchMode by mutableStateOf(false)
    private var job: Job? = null

    // The normal chat is kept on this phone (private app storage) so Meera remembers earlier conversations.
    private val historyFile: File get() = File(Meera.app.filesDir, "chat_history.json")

    init {
        if (kind == "chat") {
            try {
                val arr = JSONArray(historyFile.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    messages.add(UiMsg(o.getString("r"), o.getString("t")))
                }
            } catch (e: Exception) {
                // no saved chat yet
            }
        }
    }

    private fun saveHistory() {
        if (kind != "chat") return
        val arr = JSONArray()
        messages.filter { !it.local }.takeLast(80).forEach { arr.put(JSONObject().put("r", it.role).put("t", it.text)) }
        val text = arr.toString()
        Meera.scope.launch(Dispatchers.IO) {
            try { historyFile.writeText(text) } catch (e: Exception) { }
        }
    }

    private fun showMood(m: String) {
        if (kind == "coding") return
        Meera.setMood(m)
        Meera.scope.launch {
            delay(9000)
            if (Meera.mood.value == m) Meera.setMood("normal") // back to normal after a few seconds
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        error = null
        Meera.lastUserText = t
        // "Where am I?" and its yes/no answer are handled by the app itself and kept out of Gemini's history and the saved chat.
        val localLoc = kind != "coding" && (
            WhereAmI.match(t) || (Meera.waitingForLocationAnswer() && Answer.parse(t) != Answer.UNSURE)
        )
        messages.add(UiMsg("user", t, local = localLoc))

        // A pending question from Meera ("save this?", "send it?") is answered here, not by Gemini.
        if (kind != "coding") {
            val answer = Meera.interceptAnswer(t)
            if (answer != null) {
                messages.add(UiMsg("model", answer, local = localLoc))
                showMood(Mood.guess(answer))
                return
            }
            // "Where am I?" / "main kahan hoon" -> the app asks "Can I check your location now? (yes / no)"
            val where = Meera.askWhereAmI(t)
            if (where != null) {
                messages.add(UiMsg("model", where.text, local = true))
                showMood("normal")
                if (Meera.settings.autoSpeak) Meera.tts.speak(where.text)
                return
            }
        }

        // "Meera open your eyes" / "aankhein band karo" / "camera on|off": matched here, never sent to Gemini.
        if (kind == "chat") {
            val cmd = EyesCommands.match(t)
            if (cmd != null) {
                val reply = Meera.eyes.runCommand(cmd)
                messages.add(UiMsg("model", reply))
                showMood(Mood.guess(reply))
                return
            }
        }

        saveHistory()
        if (kind == "chat") AutoMemory.consider(t) // remember lasting facts from what the user says (Settings -> Auto memory)

        busy = true
        if (kind != "coding") Meera.setMood("thinking")
        job = Meera.scope.launch {
            try {
                val s = Meera.settings
                val history = messages.filter { it.role != "system" && !it.local }.takeLast(30).map { ChatMsg(it.role, it.text) }
                val coding = kind == "coding"
                val tools = when {
                    coding -> null
                    searchMode -> Persona.searchTools
                    else -> Persona.tools
                }
                val temp = if (coding) 0.3 else s.temperature.toDouble()
                val r = Meera.gemini.generate(s.model, Persona.system(kind), history, temp, tools = tools)
                val (clean, tagged) = Mood.split(r.text)
                val sb = StringBuilder(clean)
                if (r.sources.isNotEmpty()) sb.append("\n\nSources:\n").append(r.sources.joinToString("\n") { "• $it" })
                if (sb.isNotBlank()) messages.add(UiMsg("model", sb.toString()))
                r.calls.forEach { c ->
                    val out = Meera.handleCall(c.name, c.args)
                    // a question for the user is shown as a normal Meera message, results as a small system line
                    if (out.ask) messages.add(UiMsg("model", out.text)) else messages.add(UiMsg("system", "⚙ " + out.text))
                }
                showMood(tagged ?: Mood.guess(clean))
                saveHistory()
                if (s.autoSpeak && clean.isNotBlank()) Meera.tts.speak(clean)
            } catch (e: GeminiException) {
                error = e.message
                if (kind != "coding") Meera.setMood("sad")
            } finally {
                busy = false
            }
        }
    }

    fun stop() {
        job?.cancel(); busy = false
        if (kind != "coding") Meera.setMood("normal")
    }

    fun clear() {
        stop(); messages.clear(); error = null
        saveHistory()
    }

    /** Asks Gemini for a short summary, then Meera asks "save kar loon?" in the chat. */
    fun saveSummary() {
        if (messages.none { it.role == "user" } || busy) return
        busy = true
        Meera.scope.launch {
            try {
                val s = Meera.settings
                val convo = messages.filter { it.role != "system" && !it.local }.takeLast(30)
                    .joinToString("\n") { (if (it.role == "user") "User: " else "Meera: ") + it.text }
                val r = Meera.gemini.generate(
                    s.model, null,
                    listOf(ChatMsg("user", "Summarize the useful, lasting points of this conversation in 2-3 short sentences. Leave out passwords, OTPs and ID numbers.\n\n$convo")),
                    0.2
                )
                val sum = Mood.strip(r.text)
                if (sum.isNotBlank()) {
                    val out = Meera.confirmThen("Save this summary to memory? (yes / no)") {
                        Meera.memory.add("summary", sum)
                        "Summary saved to memory."
                    }
                    messages.add(UiMsg("model", sum + "\n\n" + out.text))
                }
            } catch (e: GeminiException) {
                error = e.message
            } finally {
                busy = false
            }
        }
    }
}
