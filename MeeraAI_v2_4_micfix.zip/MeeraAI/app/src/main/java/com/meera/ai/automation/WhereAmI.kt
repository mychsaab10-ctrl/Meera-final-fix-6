package com.meera.ai.automation

/**
 * "Where am I?" detection, done LOCALLY by the app (like EyesCommands) - Gemini is never trusted for this.
 * Works in Roman Urdu, English and Urdu script, for chat, the fallback call and the Live call (on the user's transcription).
 *
 *   English   : "where am I", "what is my location", "my current location", "tell me my location"
 *   Roman Urdu: "main kahan hoon", "mai kahan hun", "meri location batao", "meri jagah kya hai", "mera location"
 *   Urdu      : "میں کہاں ہوں", "میری لوکیشن", "میری جگہ"
 *
 * Only SHORT sentences count, and sentences about settings, sharing, directions or going somewhere do not
 * ("turn on location", "location settings", "share my location with Ali", "where am I going to eat", "navigate from my location").
 * A match never reads the location by itself: it only makes the app ask "Can I check your location now? (yes / no)".
 */
object WhereAmI {
    private val where = setOf("where", "kahan", "kahaan", "kaha", "kidhar", "kidar", "کہاں", "کدھر")
    private val selfRoman = setOf("main", "mein", "mai", "hoon", "hun", "hu", "hon", "میں", "ہوں")
    private val noun = setOf("location", "lokation", "locasion", "lokashan", "jagah", "position", "لوکیشن", "جگہ", "مقام")
    private val mine = setOf("my", "mera", "meri", "mere", "current", "maujooda", "میری", "میرا", "موجودہ")
    private val askVerb = setOf("batao", "bata", "btao", "bta", "dikhao", "dikha", "check", "tell", "show", "what", "whats", "kya", "بتاؤ", "بتا", "دکھاؤ", "کیا")
    private val block = setOf(
        "settings", "setting", "off", "on", "band", "chalu", "kholo", "open", "turn", "enable", "disable",
        "share", "send", "bhejo", "bhej", "whatsapp", "sms", "history", "navigate", "route", "directions", "guide",
        "nearby", "near", "from", "to", "se", "tak", "going", "go", "ja", "jana", "jaana", "jaun", "raha", "rahi",
        "nahi", "nahin", "mat", "not", "dont", "don", "never", "نہیں", "مت", "نہ"
    )

    private fun tokenize(text: String): List<String> =
        text.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() }

    fun match(text: String): Boolean {
        val t = tokenize(text)
        if (t.size < 2 || t.size > 7) return false
        if (t.any { it in block }) return false
        val hasWhere = t.any { it in where }
        val hasNoun = t.any { it in noun }
        val hasMine = t.any { it in mine }
        // "where am I" / "main kahan hoon"
        if (hasWhere && t.size <= 6) {
            val englishSelf = "am" in t && "i" in t
            val romanSelf = t.any { it in selfRoman }
            if (englishSelf || romanSelf) return true
        }
        // "my location" / "meri location batao" / "location batao"
        if (hasNoun && hasMine) return true
        if (hasNoun && t.size <= 6 && t.any { it in askVerb }) return true
        return false
    }
}
